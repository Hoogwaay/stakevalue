# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Standalone scripts

- `parser/main.py` — Selenium-парсер ставок stake.com + Flask-дашборд.
  Хранит данные в `parser/bets.db` (SQLite). Все настройки (интервалы,
  headless и т.п.) в начале `parser/main.py`.

  - **Локальный запуск с парсером**: `pip install -r parser/requirements.txt`,
    затем просто `python parser/main.py`. Chrome откроется автоматически
    (парсер по умолчанию ВКЛЮЧЁН вне Replit), дашборд слушает `0.0.0.0:5000`.
  - **Запуск только дашборда (Replit)**: `python parser/main.py`. Парсер
    автоматически отключается, если виден `REPL_ID`/`REPLIT_DEV_DOMAIN` —
    на Replit реального Chrome нет, и stake.com блокирует серверные IP.
    Дашборд показывает данные из существующей `bets.db`.
  - **Принудительное управление**: переменная `ENABLE_PARSER=1` всегда
    включает парсер, `ENABLE_PARSER=0` — всегда выключает (приоритет над
    автодетектом).

## Replit setup

- Workflow `Start application` запускает `python parser/main.py` на порту
  `5000` (webview).
- Deployment настроен как `autoscale` через gunicorn:
  `gunicorn --bind=0.0.0.0:5000 --reuse-port --chdir parser main:app`.
- Переменные окружения: `DASHBOARD_HOST` (по умолчанию `0.0.0.0`),
  `DASHBOARD_PORT` (по умолчанию `5000`), `ENABLE_PARSER` (`0` по умолчанию).

## Дашборд: последние изменения

- Карточка «Текущий баланс» переименована во «Всего дохода».
- Полная переделка темы в стиль **Polysure**: фиолетовый внешний фон
  (lavender gradient `#b9a3ff → #a78bfa → #8b6cf0` с белыми бликами),
  одна общая тёмная «коробка» `#16161a` с радиусом 28px, сайдбар
  с брендом «StakeScanner», текстовыми пунктами меню и активным
  пунктом-плашкой с фиолетовой левой границей. Внизу сайдбара —
  лавандовая промо-карточка со ссылкой на stake.com.
- Верхние 3 карточки получили яркие пастельные градиенты:
  жёлтый — «Всего дохода», фиолетовый — «Средний коэффициент»,
  салатовый — «ROI». Тёмные круглые иконки-стрелки в углу.
- Раскладка stats-grid: 3 колонки, под цветными карточками —
  широкий chart-card во всю ширину, ниже — оставшиеся stat-карточки.
- График «Движение баланса» интерактивный: zoom колёсиком, pinch на
  мобильном, drag-to-zoom, pan, кнопка «⟲ Сброс» и табы диапазона
  (1Н / 1М / 3М / 6М / 1Г / Всё). Подключены `chartjs-plugin-zoom`,
  `hammerjs` и `chartjs-adapter-date-fns` (CDN).
- API `/api/balance-history` агрегирует ставки по дням
  (`substr(COALESCE(NULLIF(placed_at,''), resolved_at, created_at), 1, 10)`),
  возвращает по точке на день: `{t: 'YYYY-MM-DD', balance, day_profit}`.
- Парсер вытаскивает дату постановки ставки из модалки
  (формат «25.04.2026 в 12:50 PM», см. `_extract_modal_placed_at`)
  и пишет ISO-строку `YYYY-MM-DDTHH:MM` в колонку `placed_at`. В таблице
  ставок отображается именно она; для старых записей без `placed_at`
  показывается `created_at`.
