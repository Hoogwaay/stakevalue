"""
Stake.com sports bet feed parser + Flask dashboard.

Запуск:
    pip install -r requirements.txt
    python main.py

Дашборд:  http://127.0.0.1:5555
"""

import json
import logging
import os
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

from flask import Flask, jsonify, render_template_string

try:
    from selenium import webdriver
    from selenium.common.exceptions import (
        NoSuchElementException,
        StaleElementReferenceException,
        TimeoutException,
        WebDriverException,
    )
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False

    class WebDriverException(Exception):
        pass

    class NoSuchElementException(Exception):
        pass

    class StaleElementReferenceException(Exception):
        pass

    class TimeoutException(Exception):
        pass

# ---------------------------------------------------------------------------
# Конфигурация
# ---------------------------------------------------------------------------

BASE_URL = "https://stake.com/ru/sports/live/soccer"
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bets.db")
BET_AMOUNT = 100.0
POLL_INTERVAL_SEC = 15            # как часто перечитывать ленту ставок
RESOLVE_INTERVAL_SEC = 60 * 5      # как часто пытаться обновить статусы
RESOLVE_AFTER_HOURS = 1            # начинаем пытаться определить результат уже через час
FORCE_FINALIZE_AFTER_HOURS = 48    # по истечении 2 суток фиксируем результат окончательно
HEADLESS = False                   # поставить True для фонового запуска
# Dashboard host/port — на Replit берем из переменных окружения,
# чтобы биндиться к 0.0.0.0:5000 для проксирования preview.
DASHBOARD_HOST = os.environ.get("DASHBOARD_HOST", "0.0.0.0")
DASHBOARD_PORT = int(os.environ.get("DASHBOARD_PORT", "5000"))
# Селениум-парсер: по умолчанию ВКЛЮЧЁН, чтобы при локальном запуске
# (`python parser/main.py`) Chrome открывался сам, без необходимости
# выставлять переменные окружения.
#
# Автоматически отключается, если мы видим, что окружение — Replit
# (по env `REPL_ID` / `REPLIT_DEV_DOMAIN`): там Chrome недоступен,
# а stake.com блокирует серверные IP.
#
# Принудительно управлять можно через переменную ENABLE_PARSER:
#   ENABLE_PARSER=1 — всегда включён;
#   ENABLE_PARSER=0 — всегда выключен.
_IS_REPLIT = bool(os.environ.get("REPL_ID") or os.environ.get("REPLIT_DEV_DOMAIN"))
_enable_env = os.environ.get("ENABLE_PARSER")
if _enable_env is None:
    ENABLE_PARSER = not _IS_REPLIT
else:
    ENABLE_PARSER = _enable_env == "1"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("stake-parser")

# ---------------------------------------------------------------------------
# База данных
# ---------------------------------------------------------------------------

DB_LOCK = threading.Lock()


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS bets (
                bet_id        TEXT PRIMARY KEY,
                sport         TEXT,
                players       TEXT,
                coefficient   REAL,
                placed_at     TEXT,
                amount        REAL,
                bet_type      TEXT,
                bet_target    TEXT,
                bet_url       TEXT,
                status        TEXT NOT NULL DEFAULT 'pending', -- pending|won|lost|void
                profit        REAL NOT NULL DEFAULT 0,
                created_at    TEXT NOT NULL,
                updated_at    TEXT NOT NULL,
                resolved_at   TEXT
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_status ON bets(status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_created ON bets(created_at)")


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def upsert_bet(row: dict):
    """Добавляет ставку, если её ещё нет в базе."""
    with DB_LOCK, db() as conn:
        existing = conn.execute(
            "SELECT bet_id FROM bets WHERE bet_id = ?", (row["bet_id"],)
        ).fetchone()
        if existing:
            return False
        conn.execute(
            """
            INSERT INTO bets (bet_id, sport, players, coefficient, placed_at,
                              amount, bet_type, bet_target, bet_url,
                              status, profit, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, ?, ?)
            """,
            (
                row["bet_id"],
                row.get("sport"),
                row.get("players"),
                row.get("coefficient"),
                row.get("placed_at"),
                BET_AMOUNT,
                row.get("bet_type"),
                row.get("bet_target"),
                row.get("bet_url"),
                now_iso(),
                now_iso(),
            ),
        )
        return True


def update_bet_status(bet_id: str, status: str, coefficient: float | None = None):
    """status: won|lost|void."""
    profit = 0.0
    if status == "won" and coefficient:
        profit = round(BET_AMOUNT * coefficient - BET_AMOUNT, 2)
    elif status == "lost":
        profit = -BET_AMOUNT
    with DB_LOCK, db() as conn:
        conn.execute(
            """
            UPDATE bets
               SET status = ?, profit = ?, resolved_at = ?, updated_at = ?,
                   coefficient = COALESCE(?, coefficient)
             WHERE bet_id = ? AND status = 'pending'
            """,
            (status, profit, now_iso(), now_iso(), coefficient, bet_id),
        )


def fetch_pending_bets(min_age_hours: float = 0):
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=min_age_hours)).isoformat()
    with db() as conn:
        return [
            dict(r)
            for r in conn.execute(
                "SELECT * FROM bets WHERE status = 'pending' AND created_at <= ? ORDER BY created_at",
                (cutoff,),
            ).fetchall()
        ]


# ---------------------------------------------------------------------------
# Selenium
# ---------------------------------------------------------------------------

def build_driver():
    opts = Options()
    if HEADLESS:
        opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1400,950")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--lang=ru-RU")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    driver = webdriver.Chrome(options=opts)
    driver.execute_cdp_cmd(
        "Page.addScriptToEvaluateOnNewDocument",
        {
            "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        },
    )
    driver.set_page_load_timeout(60)
    return driver


def safe_text(el):
    try:
        return el.text.strip()
    except StaleElementReferenceException:
        return ""


def parse_id_from_url(url: str) -> str | None:
    m = re.search(r"sport%3A(\d+)", url) or re.search(r"sport:(\d+)", url)
    return m.group(1) if m else None


def _parse_coef_str(s: str) -> float | None:
    """Парсит строку вида «1,73» / «1.73» / «1,73x» в float.
    Возвращает None, если не похоже на коэффициент (например, дата 25.04)."""
    if not s:
        return None
    s = s.strip().rstrip("xх×")
    m = re.fullmatch(r"(\d{1,3}[.,]\d{1,3})", s)
    if not m:
        return None
    try:
        val = float(m.group(1).replace(",", "."))
    except ValueError:
        return None
    # Разумные границы коэффициента у букмекера: ~1.01 .. 1000.
    # Это отсекает «25.04» (день.месяц) и подобные мусорные числа.
    if 1.01 <= val <= 1000.0:
        return val
    return None


def _extract_modal_coefficient(modal, text: str) -> float | None:
    """Достаёт коэффициент из модалки, опираясь на подпись «Коэффициент».

    Сначала пытаемся через DOM (надёжнее всего), потом — через текст,
    привязываясь к подписи. Регексп по сплошному тексту без привязки —
    последний резерв, и тоже с проверкой на разумный диапазон, чтобы
    не записать дату вида «25.04» как коэффициент.
    """
    # 1. DOM-путь: ищем строку с подписью «Коэффициент» и берём
    #    соседний элемент с data-testid="odds" (структура stake-модалки).
    try:
        label_xpath = (
            ".//*[normalize-space(text())='Коэффициент' "
            "or normalize-space(text())='Coefficient' "
            "or normalize-space(text())='Odds']"
        )
        for label in modal.find_elements(By.XPATH, label_xpath):
            # Поднимаемся к ближайшему контейнеру строки и ищем соседнее
            # значение коэффициента.
            try:
                row = label.find_element(
                    By.XPATH,
                    "ancestor::*["
                    ".//*[@data-testid='odds'] "
                    "or .//span[@data-ds-text='true']"
                    "][1]",
                )
            except (NoSuchElementException, WebDriverException):
                continue

            # Сначала — element с data-testid="odds" внутри этой строки.
            for odds in row.find_elements(By.CSS_SELECTOR, "[data-testid='odds']"):
                val = _parse_coef_str(safe_text(odds))
                if val is not None:
                    return val

            # Резерв: первый «жирный» span со значением.
            for span in row.find_elements(
                By.CSS_SELECTOR, "span[strong='true'], span.ds-body-md-strong"
            ):
                val = _parse_coef_str(safe_text(span))
                if val is not None:
                    return val
    except WebDriverException:
        pass

    # 2. Резерв: ищем подпись «Коэффициент» в сыром тексте и берём
    #    ближайшее число справа от неё.
    m = re.search(
        r"Коэффициент[^\d\-]{0,40}?(\d{1,3}[.,]\d{1,3})",
        text,
        re.I,
    )
    if m:
        val = _parse_coef_str(m.group(1))
        if val is not None:
            return val

    # 3. Последний резерв: первое число с разумным значением коэффициента
    #    в любом месте текста. Дата (25.04) сюда не пройдёт благодаря
    #    диапазону в _parse_coef_str.
    for cand in re.findall(r"\d{1,3}[.,]\d{1,3}", text):
        val = _parse_coef_str(cand)
        if val is not None:
            return val

    return None


_MONTHS_RU = {
    "янв": 1, "фев": 2, "мар": 3, "апр": 4, "мая": 5, "май": 5,
    "июн": 6, "июл": 7, "авг": 8, "сен": 9, "окт": 10, "ноя": 11, "дек": 12,
}


def _to_24h(hour: int, minute: int, ampm: str | None) -> tuple[int, int]:
    if ampm:
        ampm = ampm.lower()
        if ampm == "pm" and hour < 12:
            hour += 12
        elif ampm == "am" and hour == 12:
            hour = 0
    return hour, minute


def _extract_modal_placed_at(modal, text: str) -> str | None:
    """Достаёт дату и время постановки ставки из модального окна.

    Stake.com показывает блок «Кем поставлена ... <дата> в <время AM/PM>».
    Возвращает ISO-строку «YYYY-MM-DDTHH:MM:00» или None, если не нашли.
    """
    # 1. Точечный путь: блок .placed-wrap с датой/временем рядом.
    candidates: list[str] = []
    try:
        for wrap in modal.find_elements(By.CSS_SELECTOR, ".placed-wrap"):
            try:
                # Берём текст самого блока + соседнего span-а с датой/временем.
                parent = wrap.find_element(By.XPATH, "..")
                candidates.append(safe_text(parent))
            except (NoSuchElementException, WebDriverException):
                candidates.append(safe_text(wrap))
    except WebDriverException:
        pass

    # 2. Резерв: подпись «Кем поставлена» в тексте — берём ближайшее
    #    окружение справа.
    label_match = re.search(r"Кем поставлена[\s\S]{0,200}", text, re.I)
    if label_match:
        candidates.append(label_match.group(0))

    # 3. Последний резерв — весь текст модалки.
    candidates.append(text)

    # Шаблон: 25.04.2026 в 12:50 PM  /  25.04.2026 12:50  /  25 апр 2026 12:50
    iso_re = re.compile(
        r"(\d{1,2})\.(\d{1,2})\.(\d{2,4})\s*(?:в|at|,)?\s*"
        r"(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?"
    )
    ru_re = re.compile(
        r"(\d{1,2})\s+([А-Яа-я]{3,})\.?\s*(\d{4})?\s*(?:в|at|,)?\s*"
        r"(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?"
    )

    for chunk in candidates:
        if not chunk:
            continue

        m = iso_re.search(chunk)
        if m:
            day, month, year = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if year < 100:
                year += 2000
            hour, minute = _to_24h(int(m.group(4)), int(m.group(5)), m.group(6))
            try:
                return datetime(year, month, day, hour, minute).isoformat(timespec="minutes")
            except ValueError:
                continue

        m = ru_re.search(chunk)
        if m:
            day = int(m.group(1))
            month = _MONTHS_RU.get(m.group(2)[:3].lower())
            if not month:
                continue
            year = int(m.group(3)) if m.group(3) else datetime.now().year
            hour, minute = _to_24h(int(m.group(4)), int(m.group(5)), m.group(6))
            try:
                return datetime(year, month, day, hour, minute).isoformat(timespec="minutes")
            except ValueError:
                continue

    return None


def parse_modal(driver) -> dict | None:
    """Достаёт детали ставки из открытого модального окна."""
    try:
        modal = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "[data-modal-content='true']"))
        )
    except TimeoutException:
        return None

    text = safe_text(modal)
    if not text:
        return None

    data: dict = {"raw": text}

    # ID ставки
    m = re.search(r"(\d[\d\s]{5,})", text)
    if m:
        data["bet_id"] = re.sub(r"\s+", "", m.group(1))

    # Статус: Выигрыш / Проигрыш / Возврат
    if re.search(r"Выигрыш", text, re.I):
        data["status"] = "won"
    elif re.search(r"Проигрыш", text, re.I):
        data["status"] = "lost"
    elif re.search(r"Возврат|Void", text, re.I):
        data["status"] = "void"
    else:
        data["status"] = "pending"

    # Коэффициент.
    # ВАЖНО: нельзя просто взять первый \d+[.,]\d{2,3} из текста модалки —
    # он зацепит дату вида "25.04.2026" и запишет её как коэффициент.
    # Ищем строго ту строчку, где слева подпись «Коэффициент», а справа
    # значение в `data-testid="odds"` (структура из stake-modal'а).
    coef_value = _extract_modal_coefficient(modal, text)
    if coef_value is not None:
        data["coefficient"] = coef_value

    # Дата и время постановки ставки (нужны для отчётов по неделе/кварталу).
    placed_at = _extract_modal_placed_at(modal, text)
    if placed_at:
        data["placed_at"] = placed_at

    # Вид спорта (по svg-иконке). В модалке есть UI-иконки сверху (Copy,
    # Share, Close и т.д.) — их надо отсеивать, иначе спорт = "Copy".
    try:
        for icon in modal.find_elements(By.CSS_SELECTOR, "svg[data-ds-icon]"):
            try:
                name = (icon.get_attribute("data-ds-icon") or "").strip()
            except StaleElementReferenceException:
                continue
            if name and name not in UI_ICON_NAMES:
                data["sport"] = name
                break
    except WebDriverException:
        pass

    # Тип ставки и цель — пытаемся вытащить через известные подписи.
    # ВАЖНО: «Ставка» / «Сумма ставки» НЕ используем — под них попадает сумма,
    # а не выбор пользователя.
    for label, key in (
        ("Тип ставки", "bet_type"),
        ("Рынок", "bet_type"),
        ("Выбор", "bet_target"),
        ("Исход", "bet_target"),
    ):
        m = re.search(rf"{label}\s*[:\-]?\s*([^\n$]+)", text)
        if m:
            val = m.group(1).strip()
            # отсеиваем мусор вроде голой суммы/даты
            if val and not re.fullmatch(r"[\d.,\s$]+", val):
                data[key] = val

    return data


def close_modal(driver):
    """Закрываем модалку, не уходя со страницы и не теряя live-ленту."""
    try:
        driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
    except Exception:
        pass
    # на случай если ESC не сработал — снимаем query-параметры модалки
    try:
        driver.execute_script(
            "var u=new URL(window.location.href);"
            "u.searchParams.delete('modal'); u.searchParams.delete('iid');"
            "u.searchParams.delete('source');"
            "window.history.replaceState({},'',u.toString());"
        )
    except Exception:
        pass


def row_fingerprint(text: str) -> str:
    """Стабильный отпечаток строки ленты, чтобы не кликать одну и ту же ставку дважды."""
    return re.sub(r"\s+", " ", text or "").strip().lower()


# Иконки, которые точно не являются спортом (кнопки UI внутри строки)
UI_ICON_NAMES = {
    "Copy", "Share", "Close", "ChevronDown", "ChevronUp", "ChevronLeft",
    "ChevronRight", "Star", "Heart", "Settings", "Plus", "Minus",
    "Search", "Filter", "More", "GhostModeOn", "GhostModeOff",
    "Eye", "EyeOff", "Info",
}

# Подстроки в тексте строки, по которым понимаем, что это экспресс/парлей —
# такие ставки не парсим вообще.
EXPRESS_MARKERS = (
    "экспресс", "express", "parlay", "купон",
    "samegamemulti", "same game multi", "same-game multi",
)

# Если хочешь ограничить виды спорта — впиши сюда нормализованные имена
# (нижний регистр, без пробелов): {"dota2", "counterstrike"}.
# Пустой set = берём все спорты.
SPORTS_ALLOWLIST: set[str] = set()


def _norm_sport(name: str) -> str:
    return re.sub(r"\s+", "", (name or "").lower())


def is_sport_allowed(sport: str) -> bool:
    if not SPORTS_ALLOWLIST:
        return True
    return _norm_sport(sport) in SPORTS_ALLOWLIST


def detect_sport_icon(btn) -> str:
    """Возвращает имя иконки спорта внутри кнопки строки, отсеивая UI-иконки."""
    try:
        svgs = btn.find_elements(By.CSS_SELECTOR, "svg[data-ds-icon]")
    except WebDriverException:
        return ""
    for svg in svgs:
        try:
            name = (svg.get_attribute("data-ds-icon") or "").strip()
        except StaleElementReferenceException:
            continue
        if name and name not in UI_ICON_NAMES:
            return name
    return ""


def parse_row_cells(tr) -> dict:
    """Достаёт коэффициент / суммы / дату из ячеек строки таблицы.

    Стейк хранит каждое поле в отдельной `<td>`, поэтому опираемся на
    структуру, а не на регэкспы по сплошному тексту.
    """
    out: dict = {"coefficient": None, "stake": None, "payout": None, "date": None}
    try:
        tds = tr.find_elements(By.TAG_NAME, "td")
    except WebDriverException:
        return out

    for td in tds:
        try:
            t = (td.text or "").strip()
        except StaleElementReferenceException:
            continue
        if not t:
            continue

        # Дата вида 25.04 или 25.04.2026
        if re.fullmatch(r"\d{1,2}\.\d{1,2}(\.\d{2,4})?", t):
            out["date"] = t
            continue

        # Сумма: $1,234.56 / $5 000.00 / 1234.56 (с явной двух/трёхзначной копейкой)
        money_match = re.fullmatch(r"\$?\s*([\d][\d\s,]*\.\d{2,3})", t)
        if money_match:
            try:
                val = float(money_match.group(1).replace(",", "").replace(" ", ""))
                if out["stake"] is None:
                    out["stake"] = val
                else:
                    out["payout"] = val
            except ValueError:
                pass
            continue

        # Коэффициент: 1.35 / 1,35 / 2.50x. Без $, без пробелов внутри числа,
        # значение в разумных границах.
        coef_match = re.fullmatch(r"(\d{1,3}[.,]\d{1,3})\s*[xх×]?", t)
        if coef_match:
            try:
                val = float(coef_match.group(1).replace(",", "."))
                if 1.01 <= val <= 1000:
                    out["coefficient"] = val
            except ValueError:
                pass

    return out


def scrape_feed_once(driver, seen_fps: set[str]):
    """Парсим только НОВЫЕ строки. Уже знакомые — пропускаем без клика.
    Экспрессы пропускаем целиком."""
    try:
        rows = driver.find_elements(
            By.CSS_SELECTOR, "button[data-analytics='sports-open-bet-preview']"
        )
    except WebDriverException:
        return 0

    new_count = 0
    # Сначала собираем «снимок» — текст, иконку и данные ячеек у каждой строки.
    # Это надо сделать ДО первого клика, потому что после открытия модалки
    # элементы могут стать stale.
    snapshot: list[tuple[str, str, str, dict]] = []
    for btn in rows[:50]:
        try:
            btn_text = safe_text(btn)
            if not btn_text:
                continue

            # Пропускаем экспрессы
            low = btn_text.lower()
            if any(marker in low for marker in EXPRESS_MARKERS):
                # Помечаем как виденную (по тексту кнопки),
                # чтобы каждый цикл не вычислять заново
                seen_fps.add(row_fingerprint(btn_text))
                continue

            # ВАЖНО: отпечаток строим по ВСЕЙ строке <tr>, а не только
            # по тексту кнопки. Иначе одинаковые ставки разных пользователей
            # на одно и то же событие будут «склеиваться» и выглядеть как
            # одна — и мы перестанем парсить новые ставки.
            tr = None
            try:
                tr = btn.find_element(By.XPATH, "./ancestor::tr")
            except (NoSuchElementException, StaleElementReferenceException, WebDriverException):
                pass

            full_text = safe_text(tr) if tr is not None else btn_text
            fp = row_fingerprint(full_text or btn_text)
            if fp in seen_fps:
                continue

            sport_icon = detect_sport_icon(btn)

            # Если иконку определили и это НЕ из allowlist — даже не открываем
            # модалку. Если иконку не нашли — оставляем шанс проверить после.
            if sport_icon and not is_sport_allowed(sport_icon):
                seen_fps.add(fp)
                continue

            row_cells = parse_row_cells(tr) if tr is not None else {}

            snapshot.append((fp, btn_text, sport_icon, row_cells))
        except StaleElementReferenceException:
            continue

    log.info(
        "Цикл ленты: всего строк=%d, уже виденных=%d, новых к парсингу=%d",
        len(rows), len(seen_fps), len(snapshot),
    )

    if not snapshot:
        return 0

    for fp, row_text, sport_icon, row_cells in snapshot:
        # Заранее помечаем как виденную — даже если что-то пойдёт не так,
        # не будем биться об эту строку на каждом цикле.
        seen_fps.add(fp)

        # Перебираем актуальные кнопки и ищем ту, у которой совпадает текст
        try:
            buttons = driver.find_elements(
                By.CSS_SELECTOR, "button[data-analytics='sports-open-bet-preview']"
            )
        except WebDriverException:
            break

        target = None
        for b in buttons:
            try:
                tr_b = None
                try:
                    tr_b = b.find_element(By.XPATH, "./ancestor::tr")
                except (NoSuchElementException, StaleElementReferenceException, WebDriverException):
                    pass
                cmp_text = safe_text(tr_b) if tr_b is not None else (b.text or "")
                if row_fingerprint(cmp_text) == fp:
                    target = b
                    break
            except StaleElementReferenceException:
                continue
        if target is None:
            continue

        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", target)
            target.click()
        except (StaleElementReferenceException, WebDriverException):
            continue

        time.sleep(1.2)
        modal_data = parse_modal(driver) or {}
        url = driver.current_url
        bet_id = modal_data.get("bet_id") or parse_id_from_url(url)
        close_modal(driver)
        time.sleep(0.4)

        if not bet_id:
            continue

        # Финальная проверка: спорт в allowlist?
        final_sport = modal_data.get("sport") or sport_icon
        if not is_sport_allowed(final_sport):
            log.debug("Пропускаю ставку %s — спорт %r не в allowlist", bet_id, final_sport)
            continue

        # Имена игроков = текст кнопки (с очисткой пробелов)
        players = re.sub(r"\s+", " ", row_text).strip()

        coefficient = row_cells.get("coefficient") or modal_data.get("coefficient")

        row = {
            "bet_id": bet_id,
            "sport": final_sport,
            "players": players,
            "coefficient": coefficient,
            # Берём дату из модалки (полная: «2026-04-25T12:50»). Если
            # вдруг не удалось распарсить — оставляем пусто, чтобы дашборд
            # сам подставил created_at.
            "placed_at": modal_data.get("placed_at") or "",
            "bet_type": modal_data.get("bet_type"),
            "bet_target": modal_data.get("bet_target"),
            "bet_url": f"{BASE_URL}?iid=sport%3A{bet_id}&source=bet_feed_high_roller_bets&modal=bet",
        }

        if upsert_bet(row):
            new_count += 1
            log.info(
                "Новая ставка %s (%s, кф=%s)", bet_id, row["sport"], row["coefficient"]
            )

        # Если статус уже виден (ставка уже сыграла) — обновим сразу
        st = modal_data.get("status")
        if st in ("won", "lost", "void"):
            update_bet_status(bet_id, st, coefficient)

    return new_count


def resolve_pending_with(driver, pendings):
    """Перепроверяем переданные pending-ставки в отдельном браузере."""
    log.info("Перепроверяю %d pending-ставок", len(pendings))
    for bet in pendings:
        url = bet["bet_url"]
        try:
            driver.get(url)
        except WebDriverException:
            continue
        time.sleep(2.5)
        info = parse_modal(driver) or {}
        status = info.get("status", "pending")
        coef = info.get("coefficient") or bet["coefficient"]

        age = datetime.now(timezone.utc) - datetime.fromisoformat(bet["created_at"])
        if status in ("won", "lost", "void"):
            update_bet_status(bet["bet_id"], status, coef)
            log.info("Ставка %s -> %s", bet["bet_id"], status)
        elif age >= timedelta(hours=FORCE_FINALIZE_AFTER_HOURS):
            # 2 суток прошло, статус так и не определён — считаем проигрышем
            update_bet_status(bet["bet_id"], "lost", coef)
            log.info("Ставка %s принудительно закрыта как lost (>48ч)", bet["bet_id"])

        close_modal(driver)


# ---------------------------------------------------------------------------
# Фоновые воркеры (два независимых браузера)
# ---------------------------------------------------------------------------

def keep_feed_alive(driver) -> None:
    """Лёгкие действия, чтобы Stake считал вкладку активной и не глушил
    websocket-апдейты ленты: микро-скролл и фокус-событие."""
    try:
        driver.execute_script(
            "window.dispatchEvent(new Event('focus'));"
            "document.dispatchEvent(new Event('visibilitychange'));"
            "window.scrollBy(0, 1); window.scrollBy(0, -1);"
        )
    except WebDriverException:
        pass


def feed_worker():
    """Постоянно слушаем live-ленту. Страницу НЕ перезагружаем."""
    log.info("Запускаю браузер для ленты...")
    # Если за столько циклов подряд не появилось ни одной новой строки —
    # выводим предупреждение (вероятно, лента «застыла»).
    STALE_WARN_AFTER_CYCLES = max(1, 60 // POLL_INTERVAL_SEC) * 5  # ~5 минут

    while True:
        driver = None
        try:
            driver = build_driver()
            driver.get(BASE_URL)
            log.info("Открыл %s. Жду ~15 сек, пока прогрузится лента.", BASE_URL)
            time.sleep(15)

            seen_fps: set[str] = set()
            stale_cycles = 0
            warned_stale = False

            while True:
                prev_seen = len(seen_fps)
                try:
                    scrape_feed_once(driver, seen_fps)
                except Exception as e:
                    log.exception("Ошибка при парсинге ленты: %s", e)

                # Если в seen_fps не добавилось ни одного нового отпечатка,
                # значит лента не приносит новых строк.
                if len(seen_fps) == prev_seen:
                    stale_cycles += 1
                    if stale_cycles >= STALE_WARN_AFTER_CYCLES and not warned_stale:
                        log.warning(
                            "Лента не приносит новых строк уже %d циклов "
                            "(~%d сек). Возможно, Stake перестал пушить апдейты — "
                            "проверь, что вкладка не свернута и рядом нет блокировки.",
                            stale_cycles, stale_cycles * POLL_INTERVAL_SEC,
                        )
                        warned_stale = True
                else:
                    stale_cycles = 0
                    warned_stale = False

                # Чуть «подталкиваем» страницу, чтобы Stake не заглушил
                # live-обновления из-за неактивной вкладки.
                keep_feed_alive(driver)
                time.sleep(POLL_INTERVAL_SEC)
        except Exception as e:
            log.exception("Feed-воркер упал, перезапуск через 30с: %s", e)
            time.sleep(30)
        finally:
            if driver:
                try:
                    driver.quit()
                except Exception:
                    pass


def resolver_worker():
    """Раз в RESOLVE_INTERVAL_SEC проверяем pending-ставки в отдельном браузере."""
    # стартовая задержка, чтобы дать ленте набрать первые данные
    time.sleep(60)
    while True:
        try:
            pendings = fetch_pending_bets(min_age_hours=RESOLVE_AFTER_HOURS)
        except Exception as e:
            log.exception("Ошибка при чтении pending: %s", e)
            pendings = []

        if pendings:
            driver = None
            try:
                driver = build_driver()
                resolve_pending_with(driver, pendings)
            except Exception as e:
                log.exception("Resolver-воркер упал: %s", e)
            finally:
                if driver:
                    try:
                        driver.quit()
                    except Exception:
                        pass

        time.sleep(RESOLVE_INTERVAL_SEC)


# ---------------------------------------------------------------------------
# Flask дашборд
# ---------------------------------------------------------------------------

app = Flask(__name__)


DASHBOARD_HTML = r"""
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Stake parser dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.0.1/dist/chartjs-plugin-zoom.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@3.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: 'Inter', -apple-system, Segoe UI, Roboto, sans-serif;
    /* Внешний фиолетовый фон в духе Polysure: насыщенная лаванда +
       лёгкие более светлые блики по углам, чтобы было живо. */
    background:
      radial-gradient(800px 600px at 90% -10%, rgba(255,255,255,.10), transparent 60%),
      radial-gradient(900px 700px at -10% 110%, rgba(255,255,255,.08), transparent 55%),
      linear-gradient(135deg, #b9a3ff 0%, #a78bfa 50%, #8b6cf0 100%);
    color: #e7eaf3;
    min-height: 100vh;
    padding: 22px;
    -webkit-font-smoothing: antialiased;
  }

  /* ---------- layout ---------- */
  /* Тёмная «коробка» с сайдбаром и контентом, как в референсе:
     одна общая большая закруглённая панель цвета #16161a. */
  .layout {
    display: flex; gap: 0;
    max-width: 1500px; margin: 0 auto;
    background: #16161a;
    border-radius: 28px;
    box-shadow: 0 30px 80px rgba(40, 20, 90, .25);
    overflow: hidden;
  }

  .sidebar {
    width: 200px; flex: 0 0 200px;
    background: transparent;
    border: none; border-right: 1px solid rgba(255,255,255,.04);
    border-radius: 0;
    padding: 22px 16px;
    display: flex; flex-direction: column; gap: 18px;
    box-shadow: none;
  }
  .sidebar .brand {
    display: flex; align-items: center; gap: 10px;
    padding: 4px 8px 14px;
  }
  .sidebar .logo {
    width: 32px; height: 32px; border-radius: 10px;
    background: linear-gradient(135deg, #a78bfa 0%, #8b6cf0 100%);
    display: grid; place-items: center; color: #fff; font-weight: 800;
    font-size: 14px;
  }
  .sidebar .brand-name {
    font-size: 16px; font-weight: 700; letter-spacing: -0.01em; color: #fff;
  }
  .sidebar .nav-label {
    font-size: 10px; text-transform: uppercase; letter-spacing: .12em;
    color: #6b6b78; padding: 0 12px; margin-top: 4px;
  }
  .sidebar .nav { display: flex; flex-direction: column; gap: 4px; margin-top: 0; }
  .sidebar .nav button {
    width: 100%; height: 40px;
    border-radius: 10px;
    background: transparent; border: none; color: #8a8a96;
    display: flex; align-items: center; gap: 12px;
    padding: 0 12px;
    cursor: pointer; font-family: inherit; font-size: 13px; font-weight: 500;
    text-align: left;
    transition: background .15s, color .15s, transform .1s;
  }
  .sidebar .nav button .nav-ico {
    width: 18px; height: 18px; display: grid; place-items: center;
    color: inherit;
  }
  .sidebar .nav button:hover { color: #fff; background: rgba(255,255,255,.04); }
  .sidebar .nav button.active {
    color: #fff;
    background: linear-gradient(135deg, rgba(167,139,250,.22), rgba(139,108,240,.14));
    border-left: 3px solid #a78bfa;
    padding-left: 9px;
  }
  .sidebar .promo {
    margin-top: auto;
    background: linear-gradient(160deg, #c4a8ff 0%, #a78bfa 100%);
    border-radius: 16px; padding: 16px 14px;
    color: #1a1230;
    text-align: center;
  }
  .sidebar .promo h4 {
    margin: 0 0 6px; font-size: 13px; font-weight: 700; letter-spacing: -0.01em;
  }
  .sidebar .promo p {
    margin: 0 0 12px; font-size: 11px; color: rgba(26,18,48,.75); line-height: 1.4;
  }
  .sidebar .promo button {
    background: #1a1230; color: #fff; border: none;
    padding: 8px 16px; border-radius: 999px; font-size: 12px;
    font-weight: 600; cursor: pointer; font-family: inherit;
  }

  .view { display: flex; flex-direction: column; gap: 22px; }
  .view[hidden] { display: none; }

  /* ---------- select ---------- */
  .select {
    position: relative;
    background: #161618; border: 1px solid #1f1f23;
    border-radius: 999px; padding: 8px 36px 8px 14px;
    color: #d1d2db; font-size: 13px; cursor: pointer;
    font-family: inherit;
    appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23b6b7bf' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 9l6 6 6-6'/></svg>");
    background-repeat: no-repeat;
    background-position: right 12px center;
    background-size: 14px;
  }
  .select:focus { outline: none; border-color: #2f2f36; }
  .select option { background: #161618; color: #f4f5f7; }

  /* ---------- pagination ---------- */
  .pager {
    display: flex; align-items: center; justify-content: space-between;
    margin-top: 14px; gap: 12px; flex-wrap: wrap;
    color: #7a7b85; font-size: 13px;
  }
  .pager .pages { display: flex; gap: 6px; align-items: center; }
  .pager .pbtn {
    min-width: 32px; height: 32px; padding: 0 10px;
    border-radius: 10px; background: #161618; border: 1px solid #1f1f23;
    color: #d1d2db; cursor: pointer; font-size: 13px; font-family: inherit;
    display: inline-flex; align-items: center; justify-content: center;
  }
  .pager .pbtn:hover:not([disabled]) { color: #fff; background: #1c1c1f; }
  .pager .pbtn.active { background: #f4f5f7; color: #0a0a0b; border-color: #f4f5f7; }
  .pager .pbtn[disabled] { opacity: .4; cursor: not-allowed; }

  /* ---------- analytics ---------- */
  .summary-cards {
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px;
    margin-bottom: 18px;
  }
  @media (max-width: 900px) { .summary-cards { grid-template-columns: repeat(2,1fr); } }
  .winbar {
    display: inline-block; vertical-align: middle;
    width: 100px; height: 6px; border-radius: 999px;
    background: #1f1f23; overflow: hidden; margin-right: 8px;
  }
  .winbar > span { display: block; height: 100%; background: #2ecc71; }
  .winbar.low > span { background: #ff6363; }
  .winbar.mid > span { background: #f4c430; }

  /* ---------- panel (правая часть тёмной коробки) ---------- */
  .panel {
    background: transparent;
    border: none;
    border-radius: 0;
    padding: 22px 26px 26px;
    box-shadow: none;
  }
  /* main теперь живёт внутри общей тёмной коробки */
  .main { flex: 1; min-width: 0; }

  /* ---------- top bar ---------- */
  .topbar {
    display: flex; align-items: center; gap: 14px;
    margin-bottom: 18px;
  }
  .search {
    flex: 1; max-width: 360px;
    display: flex; align-items: center; gap: 10px;
    background: #161618;
    border: 1px solid #1f1f23;
    border-radius: 999px;
    padding: 10px 16px;
    color: #888892;
    font-size: 13px;
  }
  .search input {
    flex: 1; background: transparent; border: none; outline: none;
    color: #f4f5f7; font-size: 13px; font-family: inherit;
  }
  .topbar .today {
    margin-left: auto;
    color: #b6b7bf; font-size: 13px;
  }
  .icon-btn {
    width: 38px; height: 38px; border-radius: 12px;
    background: #161618; border: 1px solid #1f1f23;
    color: #b6b7bf; cursor: pointer;
    display: grid; place-items: center;
  }
  .icon-btn:hover { color: #fff; }
  .avatar {
    width: 38px; height: 38px; border-radius: 50%;
    background: linear-gradient(135deg, #6c5ce7, #fd79a8);
    display: grid; place-items: center; color: #fff; font-weight: 700;
    font-size: 14px;
  }

  /* ---------- greeting ---------- */
  .greeting h1 {
    margin: 0; font-size: 30px; font-weight: 700;
    letter-spacing: -0.02em;
  }
  .greeting p { margin: 4px 0 0; color: #7a7b85; font-size: 13px; }
  .greeting-row {
    display: flex; justify-content: space-between; align-items: flex-end;
    margin-bottom: 22px; gap: 16px;
  }
  .month-pill {
    background: #161618; border: 1px solid #1f1f23;
    color: #b6b7bf; font-size: 13px;
    padding: 9px 16px; border-radius: 999px;
    display: inline-flex; align-items: center; gap: 8px;
  }

  /* ---------- stats grid ---------- */
  /* Раскладка как в референсе: вверху 3 цветные карточки, под ними
     широкий график, и снизу — оставшиеся stat-карточки. */
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
  }
  .chart-card { grid-column: 1 / -1; min-height: 320px; }
  @media (max-width: 900px) {
    .stats-grid { grid-template-columns: 1fr 1fr; }
  }

  .stat {
    background: linear-gradient(180deg, #11162b 0%, #0d1224 100%);
    border: 1px solid rgba(255,255,255,.05);
    border-radius: 18px;
    padding: 18px 20px;
    position: relative;
    min-height: 132px;
    display: flex; flex-direction: column;
    transition: transform .15s, border-color .15s;
  }
  .stat:hover { transform: translateY(-1px); border-color: rgba(108,178,255,.25); }
  .stat .head { display: flex; justify-content: space-between; align-items: flex-start; }
  .stat .label { color: #8a90a8; font-size: 13px; }
  .stat .arrow {
    width: 28px; height: 28px; border-radius: 50%;
    background: rgba(255,255,255,.06); color: #b6b7bf;
    display: grid; place-items: center;
    font-size: 14px;
  }
  /* ---- Цветные пастельные карточки в духе Polysure ---- */
  .stat--yellow,
  .stat--purple,
  .stat--green {
    border: none;
    color: #1a1230;
  }
  .stat--yellow {
    background: linear-gradient(160deg, #fcd667 0%, #f5b945 100%);
  }
  .stat--purple {
    background: linear-gradient(160deg, #c9b1ff 0%, #a78bfa 100%);
  }
  .stat--green {
    background: linear-gradient(160deg, #cdee7a 0%, #a8e25b 100%);
  }
  .stat--yellow .label,
  .stat--purple .label,
  .stat--green .label { color: rgba(26,18,48,.65); font-weight: 500; }
  .stat--yellow .value,
  .stat--purple .value,
  .stat--green .value { color: #1a1230; }
  .stat--yellow .sub,
  .stat--purple .sub,
  .stat--green .sub { color: rgba(26,18,48,.6); }
  .stat--yellow .arrow,
  .stat--purple .arrow,
  .stat--green .arrow {
    background: #1a1230; color: #fff;
    width: 32px; height: 32px;
  }
  .stat--yellow:hover,
  .stat--purple:hover,
  .stat--green:hover { transform: translateY(-1px); border-color: transparent; }
  /* Дельта-пилюля внутри цветной карточки — затемнённая, чтобы читалась */
  .stat--yellow .delta-pill,
  .stat--purple .delta-pill,
  .stat--green .delta-pill {
    background: rgba(26,18,48,.18); color: #1a1230;
  }
  .stat .value {
    font-size: 30px; font-weight: 700; margin-top: 18px;
    letter-spacing: -0.02em;
    display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  }
  .stat .sub { color: #7a8294; font-size: 12px; margin-top: 8px; }

  .delta-pill {
    font-size: 11px; font-weight: 600;
    padding: 3px 8px; border-radius: 999px;
    display: inline-flex; align-items: center; gap: 3px;
  }
  .delta-pos { background: rgba(46,204,113,.15); color: #2ecc71; }
  .delta-neg { background: rgba(255,99,99,.15);  color: #ff6363; }
  .delta-neutral { background: rgba(160,160,170,.15); color: #b6b7bf; }

  /* ---------- chart card ---------- */
  .chart-card {
    background: linear-gradient(180deg, #11162b 0%, #0d1224 100%);
    border: 1px solid rgba(255,255,255,.05);
    border-radius: 18px;
    padding: 18px 20px;
    display: flex; flex-direction: column;
  }
  .chart-card .head {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 8px; gap: 10px; flex-wrap: wrap;
  }
  .chart-card h3 { margin: 0; font-size: 15px; font-weight: 600; }
  .chart-card .sub { color: #7a8294; font-size: 12px; }
  .range-tabs {
    display: inline-flex; background: rgba(255,255,255,.04);
    border: 1px solid rgba(255,255,255,.05);
    border-radius: 999px; padding: 3px;
  }
  .range-tabs button {
    background: transparent; border: none; color: #9aa6b8;
    padding: 6px 12px; border-radius: 999px; font-size: 12px;
    cursor: pointer; font-family: inherit; font-weight: 600;
    transition: background .15s, color .15s;
  }
  .range-tabs button:hover { color: #fff; }
  .range-tabs button.active {
    background: linear-gradient(135deg, #4f7df0, #6c5ce7); color: #fff;
  }
  .chart-reset {
    background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.05);
    color: #9aa6b8; padding: 6px 12px; border-radius: 999px;
    font-size: 12px; cursor: pointer; font-family: inherit;
  }
  .chart-reset:hover { color: #fff; background: rgba(255,255,255,.07); }
  .chart-wrap { flex: 1; min-height: 220px; }

  /* ---------- bottom panel: bets list ---------- */
  .panel-head {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 18px;
  }
  .panel-head h2 { margin: 0; font-size: 22px; font-weight: 700; letter-spacing: -0.01em; }

  .status-cards {
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px;
    margin-bottom: 18px;
  }
  @media (max-width: 900px) { .status-cards { grid-template-columns: repeat(2, 1fr); } }
  .status-card {
    border-radius: 18px; padding: 16px 18px;
    display: flex; flex-direction: column; gap: 14px;
  }
  .status-card .top {
    display: flex; justify-content: space-between; align-items: center;
    color: #2c2c33; font-weight: 600; font-size: 13px;
  }
  .status-card .row {
    display: flex; align-items: center; gap: 8px;
    color: #1d1d22;
  }
  .status-card .num { font-size: 26px; font-weight: 700; letter-spacing: -0.02em; }
  .status-card .delta {
    background: rgba(0,0,0,.18); color: #1d1d22; font-weight: 600;
    font-size: 11px; padding: 3px 8px; border-radius: 999px;
  }
  .status-card .desc { color: #2c2c33; font-size: 12px; opacity: .8; }
  .sc-pending  { background: #ffe27a; }   /* жёлтый */
  .sc-recent   { background: #aed8ff; }   /* голубой */
  .sc-won      { background: #b6f0c4; }   /* зелёный */
  .sc-lost     { background: #ff9a9a; }   /* красный */

  /* ---------- toolbar ---------- */
  .toolbar {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 14px; flex-wrap: wrap;
  }
  .toolbar .search { flex: 0 0 280px; }
  .toolbar .count { color: #7a7b85; font-size: 13px; }
  .toolbar .actions {
    margin-left: auto; display: flex; align-items: center; gap: 8px;
  }
  .btn {
    padding: 8px 14px; border-radius: 999px;
    background: #161618; border: 1px solid #1f1f23;
    color: #d1d2db; font-size: 13px; cursor: pointer;
    display: inline-flex; align-items: center; gap: 6px;
  }
  .btn.primary {
    background: #f4f5f7; color: #0a0a0b; border-color: #f4f5f7;
    font-weight: 600;
  }
  .btn:hover { color: #fff; }
  .btn.primary:hover { color: #0a0a0b; opacity: .9; }

  /* ---------- table ---------- */
  .table-wrap {
    border-radius: 16px; overflow: hidden;
    border: 1px solid #1f1f23;
  }
  table { width: 100%; border-collapse: collapse; }
  th {
    background: transparent; color: #7a7b85;
    text-transform: uppercase; font-size: 11px; letter-spacing: .08em;
    text-align: left; padding: 12px 16px; font-weight: 600;
    border-bottom: 1px solid #1f1f23;
  }
  td {
    padding: 14px 16px; font-size: 13px; color: #d1d2db;
    border-bottom: 1px solid #161618;
    vertical-align: middle;
  }
  tbody tr:last-child td { border-bottom: none; }
  tbody tr:hover { background: #131316; }
  @keyframes flash-new {
    0%   { background: rgba(46,204,113,0.28); }
    60%  { background: rgba(46,204,113,0.18); }
    100% { background: transparent; }
  }
  tbody tr.is-new { animation: flash-new 3s ease-out; }
  tbody tr.is-new td:first-child { box-shadow: inset 3px 0 0 0 #2ecc71; }

  .id-cell { display: flex; align-items: center; gap: 10px; color: #b6b7bf; }
  .id-cell .copy {
    width: 22px; height: 22px; border-radius: 6px;
    background: #1f1f23; color: #8a8b95;
    display: grid; place-items: center; cursor: pointer;
    font-size: 11px; border: none;
  }
  .id-cell .copy:hover { color: #fff; }
  .name-cell .name { color: #f4f5f7; font-weight: 500; }
  .name-cell .sub { color: #7a7b85; font-size: 11px; margin-top: 2px; }
  .pos { color: #2ecc71; }
  .neg { color: #ff6363; }

  .pill {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 4px 12px; border-radius: 999px;
    font-size: 11px; font-weight: 600; text-transform: capitalize;
  }
  .pill.won  { background: #b6f0c4; color: #134e2a; }   /* зелёный */
  .pill.lost { background: #ff9a9a; color: #5a0e0e; }   /* красный */
  .pill.pending { background: #ffe27a; color: #5a4400; } /* жёлтый */
  .pill.void { background: #d6d6dc; color: #2c2c33; }
  .pill .dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; opacity: .7; }

  .row-link { color: #b6b7bf; text-decoration: none; padding: 4px 6px; border-radius: 8px; }
  .row-link:hover { color: #fff; background: #1f1f23; }

  .updated { color: #5a5b65; font-size: 11px; margin-top: 14px; text-align: right; }

  /* simple svg icons */
  .ic { width: 16px; height: 16px; stroke: currentColor; fill: none; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
</style>
</head>
<body>

<div class="layout">

  <aside class="sidebar">
    <div class="brand">
      <div class="logo">S</div>
      <div class="brand-name">StakeScanner</div>
    </div>
    <div class="nav-label">Меню</div>
    <div class="nav">
      <button class="nav-tab active" data-view="dashboard">
        <span class="nav-ico"><svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></span>
        <span>Дашборд</span>
      </button>
      <button class="nav-tab" data-view="history">
        <span class="nav-ico"><svg class="ic" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 9h8M8 13h8M8 17h5"/></svg></span>
        <span>Ставки</span>
      </button>
      <button class="nav-tab" data-view="analytics">
        <span class="nav-ico"><svg class="ic" viewBox="0 0 24 24"><path d="M4 4v16h16"/><path d="M7 14l3-3 3 3 5-6"/></svg></span>
        <span>Аналитика</span>
      </button>
    </div>
    <div class="promo">
      <h4>StakeScanner</h4>
      <p>Парсер ставок stake.com и аналитика прямо в одной панели.</p>
      <button onclick="window.open('https://stake.com','_blank')">Открыть Stake</button>
    </div>
  </aside>

  <main class="main">

    <!-- ===== VIEW: DASHBOARD ===== -->
    <section class="view" id="view-dashboard">
    <section class="panel">
      <div class="topbar">
        <div class="search">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          <input placeholder="Поиск" />
        </div>
        <div class="today" id="today">—</div>
        <button class="icon-btn" title="Настройки">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>
        </button>
        <button class="icon-btn" title="Уведомления">
          <svg class="ic" viewBox="0 0 24 24"><path d="M18 16v-5a6 6 0 1 0-12 0v5l-2 3h16z"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>
        </button>
        <div class="avatar">S</div>
      </div>

      <div class="greeting-row">
        <div class="greeting">
          <h1>Привет! 👋</h1>
          <p>Вот что происходит со ставками прямо сейчас.</p>
        </div>
        <div class="month-pill">
          За всё время
          <svg class="ic" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>
        </div>
      </div>

      <div class="stats-grid">
        <div class="stat stat--yellow">
          <div class="head">
            <div class="label">Всего дохода</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value"><span id="balance">—</span><span class="delta-pill delta-pos" id="balance-delta">0%</span></div>
          <div class="sub">по всем сыгравшим ставкам</div>
        </div>

        <div class="stat stat--purple">
          <div class="head">
            <div class="label">Средний коэффициент</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value"><span id="avgcoef">—</span></div>
          <div class="sub">среди всех ставок в базе</div>
        </div>

        <div class="stat stat--green">
          <div class="head">
            <div class="label">ROI</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value"><span id="roi">—</span></div>
          <div class="sub">профит / общая ставка</div>
        </div>

        <div class="chart-card">
          <div class="head">
            <div>
              <h3>Движение баланса</h3>
              <div class="sub">по дням, кумулятивный итог</div>
            </div>
            <div class="range-tabs" id="range-tabs">
              <button data-range="7">1Н</button>
              <button data-range="30">1М</button>
              <button data-range="90">3М</button>
              <button data-range="180">6М</button>
              <button data-range="365">1Г</button>
              <button data-range="all" class="active">Всё</button>
            </div>
            <button class="chart-reset" id="chart-reset" title="Сбросить масштаб">⟲ Сброс</button>
          </div>
          <div class="chart-wrap"><canvas id="chart"></canvas></div>
        </div>

        <div class="stat">
          <div class="head">
            <div class="label">Винрейт</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value"><span id="winrate">—</span></div>
          <div class="sub" id="winrate-sub">— из — сыгравших</div>
        </div>

        <div class="stat">
          <div class="head">
            <div class="label">Максимальный выигрыш</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value pos"><span id="maxwin">—</span></div>
          <div class="sub">самая удачная ставка</div>
        </div>

        <div class="stat">
          <div class="head">
            <div class="label">Всего ставок</div>
            <div class="arrow">↗</div>
          </div>
          <div class="value"><span id="total">—</span><span class="delta-pill delta-neutral" id="pendingPill">0 в ожидании</span></div>
          <div class="sub" id="settledLabel">сыграло: 0</div>
        </div>
      </div>
    </section>
    </section><!-- /view-dashboard -->

    <!-- ===== VIEW: HISTORY ===== -->
    <section class="view" id="view-history" hidden>
    <section class="panel">
      <div class="topbar">
        <div class="search">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          <input id="filter" placeholder="Поиск по игрокам или ID" />
        </div>
        <div style="margin-left:auto"></div>
        <button class="icon-btn" title="Настройки">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19 12c0-.4 0-.8-.1-1.2"/></svg>
        </button>
        <button class="icon-btn" title="Уведомления">
          <svg class="ic" viewBox="0 0 24 24"><path d="M18 16v-5a6 6 0 1 0-12 0v5l-2 3h16z"/></svg>
        </button>
        <div class="avatar">S</div>
      </div>

      <div class="panel-head">
        <h2>История ставок</h2>
      </div>

      <div class="status-cards">
        <div class="status-card sc-pending">
          <div class="top"><span>В ожидании</span><svg class="ic" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
          <div class="row"><div class="num" id="card-pending">0</div><div class="delta">за всё время</div></div>
          <div class="desc">пока не сыграли</div>
        </div>
        <div class="status-card sc-recent">
          <div class="top"><span>За 24 часа</span><svg class="ic" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
          <div class="row"><div class="num" id="card-recent">0</div><div class="delta">новых</div></div>
          <div class="desc">добавлено за сутки</div>
        </div>
        <div class="status-card sc-won">
          <div class="top"><span>Выиграли</span><svg class="ic" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
          <div class="row"><div class="num" id="card-won">0</div><div class="delta">всего</div></div>
          <div class="desc">с положительным профитом</div>
        </div>
        <div class="status-card sc-lost">
          <div class="top"><span>Проиграли</span><svg class="ic" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
          <div class="row"><div class="num" id="card-lost">0</div><div class="delta">всего</div></div>
          <div class="desc">отминусовали</div>
        </div>
      </div>

      <div class="toolbar">
        <select id="filter-sport" class="select" title="Вид спорта">
          <option value="">Все виды спорта</option>
        </select>
        <select id="filter-status" class="select" title="Статус">
          <option value="">Все статусы</option>
          <option value="pending">В ожидании</option>
          <option value="won">Выиграла</option>
          <option value="lost">Проиграла</option>
          <option value="void">Возврат</option>
        </select>
        <select id="filter-pagesize" class="select" title="Записей на странице">
          <option value="10">10 на странице</option>
          <option value="25" selected>25 на странице</option>
          <option value="50">50 на странице</option>
          <option value="100">100 на странице</option>
          <option value="0">Все</option>
        </select>
        <div class="count" id="count">0 ставок</div>
        <div class="actions">
          <button class="btn primary" onclick="location.reload()">
            <svg class="ic" viewBox="0 0 24 24" style="stroke:#0a0a0b"><path d="M4 12a8 8 0 0 1 14-5l2-2v6h-6l2-2a6 6 0 1 0 1.7 6.5"/></svg>
            Обновить
          </button>
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Игроки</th>
              <th>Спорт</th>
              <th>Цель</th>
              <th>Кф</th>
              <th>Сумма</th>
              <th>Профит</th>
              <th>Статус</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="tbody"></tbody>
        </table>
      </div>

      <div class="pager">
        <div id="pager-info">—</div>
        <div class="pages" id="pager-pages"></div>
      </div>

      <div class="updated" id="updated"></div>
    </section>
    </section><!-- /view-history -->

    <!-- ===== VIEW: ANALYTICS ===== -->
    <section class="view" id="view-analytics" hidden>
    <section class="panel">
      <div class="topbar">
        <div class="search">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
          <input id="analytics-search" placeholder="Поиск по виду спорта" />
        </div>
        <div style="margin-left:auto"></div>
        <button class="icon-btn" title="Настройки">
          <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/></svg>
        </button>
        <button class="icon-btn" title="Уведомления">
          <svg class="ic" viewBox="0 0 24 24"><path d="M18 16v-5a6 6 0 1 0-12 0v5l-2 3h16z"/></svg>
        </button>
        <div class="avatar">S</div>
      </div>

      <div class="panel-head">
        <h2>Аналитика по видам спорта</h2>
      </div>

      <div class="summary-cards">
        <div class="stat">
          <div class="head"><div class="label">Винрейт общий</div><div class="arrow">↗</div></div>
          <div class="value"><span id="ana-winrate">—</span></div>
          <div class="sub"><span id="ana-winrate-sub">—</span></div>
        </div>
        <div class="stat">
          <div class="head"><div class="label">ROI</div><div class="arrow">↗</div></div>
          <div class="value"><span id="ana-roi">—</span></div>
          <div class="sub">профит / общая ставка</div>
        </div>
        <div class="stat">
          <div class="head"><div class="label">Лучший спорт</div><div class="arrow">↗</div></div>
          <div class="value"><span id="ana-best">—</span></div>
          <div class="sub" id="ana-best-sub">—</div>
        </div>
        <div class="stat">
          <div class="head"><div class="label">Худший спорт</div><div class="arrow">↗</div></div>
          <div class="value"><span id="ana-worst">—</span></div>
          <div class="sub" id="ana-worst-sub">—</div>
        </div>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th data-sort="sport">Спорт</th>
              <th data-sort="total">Всего</th>
              <th data-sort="settled">Сыграло</th>
              <th data-sort="won">Выиграло</th>
              <th data-sort="winrate">Винрейт</th>
              <th data-sort="avg_coef">Средний кф</th>
              <th data-sort="stake">Ставка</th>
              <th data-sort="profit">Профит</th>
              <th data-sort="roi">ROI</th>
            </tr>
          </thead>
          <tbody id="ana-tbody"></tbody>
        </table>
      </div>
    </section>
    </section><!-- /view-analytics -->
  </main>
</div>

<script>
let chart;
let allItems = [];
let currentPage = 1;
let isFirstLoad = true;
const flashedIds = new Set();  // ID, для которых анимация «новая ставка» уже сыграла

function escapeHtml(s){
  return String(s||'').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

function fmtMoney(v){
  const sign = v > 0 ? '+' : v < 0 ? '−' : '';
  return sign + Math.abs(v).toFixed(2);
}

const STATUS_LABELS = { won:'Выиграла', lost:'Проиграла', pending:'В ожидании', void:'Возврат' };

// ---------- tab switching ----------
const VIEWS = ['dashboard', 'history', 'analytics'];
document.querySelectorAll('.nav-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const view = btn.dataset.view;
    VIEWS.forEach(v => {
      document.getElementById('view-' + v).hidden = (v !== view);
    });
  });
});

// ---------- analytics state ----------
let anaSort = { key: 'profit', dir: -1 };  // -1 desc, +1 asc

function populateSportOptions(items){
  const sel = document.getElementById('filter-sport');
  const current = sel.value;
  const sports = Array.from(new Set(items.map(b => b.sport).filter(Boolean))).sort();
  sel.innerHTML = '<option value="">Все виды спорта</option>' +
    sports.map(s => `<option value="${escapeHtml(s)}"${s===current?' selected':''}>${escapeHtml(s)}</option>`).join('');
}

async function refresh() {
  let stats, hist, bets;
  try {
    [stats, hist, bets] = await Promise.all([
      fetch('/api/stats').then(r=>r.json()),
      fetch('/api/balance-history').then(r=>r.json()),
      fetch('/api/bets').then(r=>r.json())
    ]);
  } catch (e) {
    // Сеть моргнула — не валим интервал, просто пропускаем тик.
    console.warn('refresh failed, skip tick:', e);
    return;
  }

  const items = bets.items;

  // На первом рендере считаем все ставки уже «виденными» — не мигаем,
  // мигаем только то, что появилось в последующих обновлениях.
  if (isFirstLoad) {
    items.forEach(b => flashedIds.add(b.bet_id));
    isFirstLoad = false;
  }

  allItems = items;
  populateSportOptions(items);

  // ---- top stats ----
  document.getElementById('balance').textContent = fmtMoney(stats.balance);
  const bd = document.getElementById('balance-delta');
  bd.textContent = (stats.balance >= 0 ? '+' : '') + stats.balance.toFixed(2);
  bd.className = 'delta-pill ' + (stats.balance > 0 ? 'delta-pos' : stats.balance < 0 ? 'delta-neg' : 'delta-neutral');

  document.getElementById('avgcoef').textContent = stats.avg_coef ? stats.avg_coef.toFixed(3) : '—';
  document.getElementById('maxwin').textContent = stats.max_win ? '+' + stats.max_win.toFixed(2) : '—';
  document.getElementById('total').textContent = stats.total;
  document.getElementById('pendingPill').textContent = stats.pending + ' в ожидании';
  document.getElementById('settledLabel').textContent = 'сыграло: ' + stats.settled;

  // ---- ROI и Винрейт (на основе сыгравших ставок) ----
  const settled = items.filter(b => b.status === 'won' || b.status === 'lost');
  const wonCnt = items.filter(b => b.status === 'won').length;
  const stake = settled.reduce((s,b) => s + (b.amount || 0), 0);
  const profit = settled.reduce((s,b) => s + (b.profit || 0), 0);
  const roiVal = stake ? (profit / stake) * 100 : 0;
  const winrateVal = settled.length ? (wonCnt / settled.length) * 100 : 0;

  const roiEl = document.getElementById('roi');
  roiEl.textContent = settled.length ? (roiVal>=0?'+':'') + roiVal.toFixed(1) + '%' : '—';
  roiEl.className = 'value ' + (roiVal>0 ? 'pos' : roiVal<0 ? 'neg' : '');

  const wrEl = document.getElementById('winrate');
  wrEl.textContent = settled.length ? winrateVal.toFixed(1) + '%' : '—';
  wrEl.className = 'value ' + (winrateVal>=55 ? 'pos' : winrateVal<40 && settled.length ? 'neg' : '');
  document.getElementById('winrate-sub').textContent = `${wonCnt} из ${settled.length} сыгравших`;

  // ---- bottom status cards ----
  const won = items.filter(b=>b.status==='won').length;
  const lost = items.filter(b=>b.status==='lost').length;
  const pending = items.filter(b=>b.status==='pending').length;
  const dayAgo = Date.now() - 24*60*60*1000;
  const recent = items.filter(b => new Date(b.created_at).getTime() >= dayAgo).length;
  document.getElementById('card-pending').textContent = pending;
  document.getElementById('card-recent').textContent = recent;
  document.getElementById('card-won').textContent = won;
  document.getElementById('card-lost').textContent = lost;

  // ---- today / updated ----
  const now = new Date();
  document.getElementById('today').textContent = now.toLocaleDateString('ru-RU', {
    weekday:'short', day:'numeric', month:'short'
  }).replace('.', '');
  document.getElementById('updated').textContent = 'Обновлено: ' + now.toLocaleTimeString('ru-RU');

  // ---- chart ----
  histPoints = hist.points || [];
  renderChart();

  renderTable();
  renderAnalytics();
}

// ---------- chart (интерактивный, по дням) ----------
let histPoints = [];
let activeRangeDays = 'all';

function pointsForRange(days) {
  if (days === 'all' || !histPoints.length) return histPoints;
  const cutoff = Date.now() - days * 86400000;
  // Берём все точки за окно + последнюю «до окна» как стартовую,
  // чтобы баланс на графике не начинался с 0.
  let startIdx = 0;
  for (let i = 0; i < histPoints.length; i++) {
    if (new Date(histPoints[i].t).getTime() < cutoff) startIdx = i;
    else break;
  }
  return histPoints.slice(startIdx);
}

function renderChart() {
  const ctx = document.getElementById('chart').getContext('2d');
  if (chart) chart.destroy();
  const grad = ctx.createLinearGradient(0, 0, 0, 240);
  grad.addColorStop(0, 'rgba(108,178,255,0.35)');
  grad.addColorStop(1, 'rgba(108,178,255,0)');

  const pts = pointsForRange(activeRangeDays);
  // Каждая точка = один день: x — дата, y — кумулятивный баланс на конец дня.
  const data = pts.map(p => ({ x: p.t, y: p.balance, dayProfit: p.day_profit }));

  chart = new Chart(ctx, {
    type: 'line',
    data: {
      datasets: [{
        data,
        borderColor: '#6cb2ff',
        backgroundColor: grad,
        borderWidth: 2.5,
        fill: true, tension: 0.3,
        pointRadius: 3, pointHoverRadius: 6,
        pointBackgroundColor: '#0d1224', pointBorderColor: '#6cb2ff', pointBorderWidth: 2,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(13,18,36,0.95)',
          borderColor: 'rgba(255,255,255,0.08)',
          borderWidth: 1,
          padding: 12,
          titleColor: '#9aa6b8',
          bodyColor: '#e7eaf3',
          callbacks: {
            title: (items) => {
              const d = new Date(items[0].parsed.x);
              return d.toLocaleDateString('ru-RU', { day:'2-digit', month:'long', year:'numeric' });
            },
            label: (ctx) => {
              const v = ctx.parsed.y;
              const dp = ctx.raw && typeof ctx.raw.dayProfit === 'number' ? ctx.raw.dayProfit : null;
              const lines = [`Баланс: ${(v>=0?'+':'')}${v.toFixed(2)}`];
              if (dp !== null) lines.push(`За день: ${(dp>=0?'+':'')}${dp.toFixed(2)}`);
              return lines;
            }
          }
        },
        zoom: {
          pan:  { enabled: true, mode: 'x', modifierKey: null },
          zoom: {
            wheel: { enabled: true },
            pinch: { enabled: true },
            drag:  { enabled: true, backgroundColor: 'rgba(108,178,255,0.12)', borderColor: 'rgba(108,178,255,0.4)', borderWidth: 1 },
            mode: 'x',
          },
          limits: { x: { minRange: 86400000 * 2 } } // минимум 2 дня по оси X
        }
      },
      scales: {
        x: {
          type: 'time',
          time: { unit: 'day', tooltipFormat: 'dd.MM.yyyy', displayFormats: { day: 'dd MMM' } },
          ticks: { color: '#7a8294', maxRotation: 0, autoSkip: true, maxTicksLimit: 8, source: 'auto' },
          grid: { display: false }
        },
        y: { ticks: { color: '#7a8294' }, grid: { color: 'rgba(255,255,255,.05)', drawBorder: false } }
      }
    }
  });
}

document.querySelectorAll('#range-tabs button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#range-tabs button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const v = btn.dataset.range;
    activeRangeDays = v === 'all' ? 'all' : parseInt(v, 10);
    renderChart();
  });
});

document.getElementById('chart-reset').addEventListener('click', () => {
  if (chart && chart.resetZoom) chart.resetZoom();
});

function computeSportStats(items){
  const map = new Map();
  for (const b of items) {
    const sp = b.sport || '—';
    let row = map.get(sp);
    if (!row) {
      row = { sport: sp, total: 0, settled: 0, won: 0, lost: 0, pending: 0,
              stake: 0, profit: 0, _coefSum: 0, _coefN: 0 };
      map.set(sp, row);
    }
    row.total += 1;
    row.stake += (b.amount || 0);
    if (b.coefficient) { row._coefSum += b.coefficient; row._coefN += 1; }
    if (b.status === 'won')  { row.settled += 1; row.won  += 1; row.profit += (b.profit||0); }
    else if (b.status === 'lost') { row.settled += 1; row.lost += 1; row.profit += (b.profit||0); }
    else if (b.status === 'pending') { row.pending += 1; }
  }
  const arr = [...map.values()].map(r => ({
    ...r,
    avg_coef: r._coefN ? r._coefSum / r._coefN : 0,
    winrate: r.settled ? r.won / r.settled : 0,
    roi: r.stake ? r.profit / r.stake : 0,
  }));
  return arr;
}

function renderAnalytics(){
  const rows = computeSportStats(allItems);

  // overall stats
  const tot = rows.reduce((a,r) => ({
    settled: a.settled + r.settled, won: a.won + r.won,
    stake: a.stake + r.stake, profit: a.profit + r.profit
  }), { settled:0, won:0, stake:0, profit:0 });

  const ovWin = tot.settled ? tot.won / tot.settled : 0;
  const ovRoi = tot.stake ? tot.profit / tot.stake : 0;
  document.getElementById('ana-winrate').textContent = (ovWin*100).toFixed(1) + '%';
  document.getElementById('ana-winrate-sub').textContent = `${tot.won} из ${tot.settled} сыгравших`;
  document.getElementById('ana-roi').textContent = (ovRoi>=0?'+':'') + (ovRoi*100).toFixed(1) + '%';

  // best / worst by profit (only sports with at least 1 settled bet)
  const settledRows = rows.filter(r => r.settled > 0);
  const best  = settledRows.slice().sort((a,b)=>b.profit-a.profit)[0];
  const worst = settledRows.slice().sort((a,b)=>a.profit-b.profit)[0];
  document.getElementById('ana-best').textContent  = best  ? best.sport  : '—';
  document.getElementById('ana-best-sub').textContent  = best  ? `${best.profit>=0?'+':''}${best.profit.toFixed(2)} • винрейт ${(best.winrate*100).toFixed(0)}%` : '—';
  document.getElementById('ana-worst').textContent = worst ? worst.sport : '—';
  document.getElementById('ana-worst-sub').textContent = worst ? `${worst.profit>=0?'+':''}${worst.profit.toFixed(2)} • винрейт ${(worst.winrate*100).toFixed(0)}%` : '—';

  // search filter
  const q = (document.getElementById('analytics-search').value || '').trim().toLowerCase();
  let view = q ? rows.filter(r => r.sport.toLowerCase().includes(q)) : rows;

  // sorting
  const { key, dir } = anaSort;
  view = view.slice().sort((a,b) => {
    const va = a[key], vb = b[key];
    if (typeof va === 'string') return va.localeCompare(vb) * dir;
    return ((va||0) - (vb||0)) * dir;
  });

  document.getElementById('ana-tbody').innerHTML = view.map(r => {
    const wrPct = (r.winrate*100).toFixed(0);
    const wrCls = r.winrate < 0.4 ? 'low' : r.winrate < 0.55 ? 'mid' : '';
    const profitCls = r.profit>0 ? 'pos' : r.profit<0 ? 'neg' : '';
    const roiCls = r.roi>0 ? 'pos' : r.roi<0 ? 'neg' : '';
    const profitTxt = (r.profit>=0?'+':'') + r.profit.toFixed(2);
    const roiTxt = (r.roi>=0?'+':'') + (r.roi*100).toFixed(1) + '%';
    return `
      <tr>
        <td><div class="name-cell"><div class="name">${escapeHtml(r.sport)}</div></div></td>
        <td>${r.total}</td>
        <td>${r.settled}</td>
        <td>${r.won}</td>
        <td><span class="winbar ${wrCls}"><span style="width:${wrPct}%"></span></span>${wrPct}%</td>
        <td>${r.avg_coef ? r.avg_coef.toFixed(2) : '—'}</td>
        <td>${r.stake.toFixed(0)}</td>
        <td class="${profitCls}">${profitTxt}</td>
        <td class="${roiCls}">${r.settled ? roiTxt : '—'}</td>
      </tr>`;
  }).join('') || `<tr><td colspan="9" style="text-align:center;color:#7a7b85;padding:30px">Пока нет данных</td></tr>`;
}

function renderTable(){
  const ft = (document.getElementById('filter').value || '').trim().toLowerCase();
  const sportF = document.getElementById('filter-sport').value;
  const statusF = document.getElementById('filter-status').value;
  const pageSize = parseInt(document.getElementById('filter-pagesize').value, 10) || 0;

  let filtered = allItems;
  if (ft) filtered = filtered.filter(b => (b.players||'').toLowerCase().includes(ft) || (b.bet_id||'').toLowerCase().includes(ft));
  if (sportF) filtered = filtered.filter(b => b.sport === sportF);
  if (statusF) filtered = filtered.filter(b => b.status === statusF);

  const total = filtered.length;
  const totalPages = pageSize > 0 ? Math.max(1, Math.ceil(total / pageSize)) : 1;
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;

  const pageItems = pageSize > 0
    ? filtered.slice((currentPage-1)*pageSize, currentPage*pageSize)
    : filtered;

  document.getElementById('count').textContent = total + ' ставок';

  document.getElementById('tbody').innerHTML = pageItems.map(b => {
    const profit = b.profit || 0;
    const profitTxt = profit ? (profit>0?'+':'') + profit.toFixed(2) : '—';
    const profitCls = profit>0 ? 'pos' : profit<0 ? 'neg' : '';
    // Дата постановки берётся из модального окна (поле `placed_at`).
    // Если её нет (старые ставки) — показываем дату попадания в нашу базу.
    const placedRaw = b.placed_at || b.created_at;
    const placedAt = new Date(placedRaw).toLocaleString('ru-RU', {
      day:'2-digit', month:'2-digit', year:'2-digit',
      hour:'2-digit', minute:'2-digit'
    });
    const isNew = !flashedIds.has(b.bet_id);
    return `
      <tr class="${isNew ? 'is-new' : ''}">
        <td>
          <div class="id-cell">
            <button class="copy" onclick="navigator.clipboard.writeText('${escapeHtml(b.bet_id)}')">⧉</button>
            <span>#${escapeHtml(b.bet_id)}</span>
          </div>
        </td>
        <td>
          <div class="name-cell">
            <div class="name">${escapeHtml(b.players||'—')}</div>
            <div class="sub">${placedAt}</div>
          </div>
        </td>
        <td>${escapeHtml(b.sport||'—')}</td>
        <td>${escapeHtml(b.bet_target || b.bet_type || '—')}</td>
        <td>${b.coefficient ? b.coefficient.toFixed(2) : '—'}</td>
        <td>${b.amount.toFixed(0)}</td>
        <td class="${profitCls}">${profitTxt}</td>
        <td><span class="pill ${b.status}"><span class="dot"></span>${STATUS_LABELS[b.status]||b.status}</span></td>
        <td><a class="row-link" href="${escapeHtml(b.bet_url)}" target="_blank">↗</a></td>
      </tr>`;
  }).join('') || `<tr><td colspan="9" style="text-align:center;color:#7a7b85;padding:30px">Ничего не найдено</td></tr>`;

  // Помечаем все только что показанные ставки как «уже мигнувшие»,
  // чтобы анимация не повторялась при следующих обновлениях.
  pageItems.forEach(b => flashedIds.add(b.bet_id));

  renderPager(total, totalPages, pageSize);
}

function renderPager(total, totalPages, pageSize){
  const info = document.getElementById('pager-info');
  const pages = document.getElementById('pager-pages');

  if (pageSize === 0 || total === 0) {
    info.textContent = total ? `Показано все ${total}` : 'Нет записей';
    pages.innerHTML = '';
    return;
  }

  const from = (currentPage - 1) * pageSize + 1;
  const to = Math.min(currentPage * pageSize, total);
  info.textContent = `${from}–${to} из ${total}`;

  // build page list with ellipsis
  const set = new Set([1, totalPages, currentPage, currentPage-1, currentPage+1]);
  const list = [...set].filter(p => p >= 1 && p <= totalPages).sort((a,b)=>a-b);
  let html = `<button class="pbtn" data-p="${currentPage-1}" ${currentPage<=1?'disabled':''}>‹</button>`;
  let prev = 0;
  for (const p of list) {
    if (p - prev > 1) html += `<span style="padding:0 4px;color:#5a5b65">…</span>`;
    html += `<button class="pbtn ${p===currentPage?'active':''}" data-p="${p}">${p}</button>`;
    prev = p;
  }
  html += `<button class="pbtn" data-p="${currentPage+1}" ${currentPage>=totalPages?'disabled':''}>›</button>`;
  pages.innerHTML = html;
  pages.querySelectorAll('.pbtn').forEach(btn => {
    btn.addEventListener('click', () => {
      const p = parseInt(btn.dataset.p, 10);
      if (!isNaN(p)) { currentPage = p; renderTable(); }
    });
  });
}

document.getElementById('filter').addEventListener('input', () => { currentPage = 1; renderTable(); });
document.getElementById('filter-sport').addEventListener('change', () => { currentPage = 1; renderTable(); });
document.getElementById('filter-status').addEventListener('change', () => { currentPage = 1; renderTable(); });
document.getElementById('filter-pagesize').addEventListener('change', () => { currentPage = 1; renderTable(); });

document.getElementById('analytics-search').addEventListener('input', renderAnalytics);
document.querySelectorAll('#view-analytics th[data-sort]').forEach(th => {
  th.style.cursor = 'pointer';
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    if (anaSort.key === key) anaSort.dir *= -1;
    else { anaSort.key = key; anaSort.dir = (key === 'sport' ? 1 : -1); }
    renderAnalytics();
  });
});

refresh();
setInterval(refresh, 5000);

// Полная перезагрузка страницы раз в 10 минут.
// Браузер «усыпляет» вкладки, на которых давно нет активности, и таймеры
// начинают тормозить или фоновые соединения падают — после этого лента
// перестаёт обновляться, пока не нажать F5. Чтобы пользователю не нужно
// было это делать, перезагружаем страницу сами раз в 10 минут.
setTimeout(() => location.reload(), 10 * 60 * 1000);
</script>
</body>
</html>
"""


@app.route("/")
def dashboard():
    return render_template_string(DASHBOARD_HTML)


@app.route("/api/stats")
def api_stats():
    with db() as conn:
        rows = conn.execute("SELECT * FROM bets").fetchall()

    total = len(rows)
    pending = sum(1 for r in rows if r["status"] == "pending")
    settled = [r for r in rows if r["status"] in ("won", "lost", "void")]
    balance = round(sum(r["profit"] for r in rows), 2)
    coefs = [r["coefficient"] for r in rows if r["coefficient"]]
    avg_coef = round(sum(coefs) / len(coefs), 3) if coefs else 0
    wins = [r["profit"] for r in rows if r["status"] == "won"]
    max_win = round(max(wins), 2) if wins else 0

    return jsonify(
        {
            "total": total,
            "pending": pending,
            "settled": len(settled),
            "balance": balance,
            "avg_coef": avg_coef,
            "max_win": max_win,
        }
    )


@app.route("/api/balance-history")
def api_history():
    """Точки графика: одна метка = один день.

    Берём фактически сыгравшие ставки (won/lost/void), группируем по дате
    события (дата постановки, если она есть; иначе — дата создания) и
    отдаём кумулятивный баланс на конец каждого дня.
    """
    with db() as conn:
        rows = conn.execute(
            "SELECT "
            "  substr(COALESCE("
            "    NULLIF(placed_at,''), resolved_at, created_at"
            "  ), 1, 10) AS d, "
            "  SUM(profit) AS day_profit "
            "FROM bets "
            "WHERE status IN ('won','lost','void') "
            "GROUP BY d "
            "ORDER BY d"
        ).fetchall()

    points = []
    bal = 0.0
    for r in rows:
        if not r["d"]:
            continue
        bal = round(bal + (r["day_profit"] or 0), 2)
        points.append({"t": r["d"], "balance": bal, "day_profit": round(r["day_profit"] or 0, 2)})
    return jsonify({"points": points})


@app.route("/api/bets")
def api_bets():
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM bets ORDER BY created_at DESC LIMIT 100"
        ).fetchall()
    return jsonify({"items": [dict(r) for r in rows]})


# ---------------------------------------------------------------------------
# Точка входа
# ---------------------------------------------------------------------------

def main():
    init_db()
    if ENABLE_PARSER and SELENIUM_AVAILABLE:
        log.info("Запускаю Selenium-парсер (feed + resolver).")
        threading.Thread(target=feed_worker, daemon=True, name="feed").start()
        threading.Thread(target=resolver_worker, daemon=True, name="resolver").start()
    else:
        if not ENABLE_PARSER:
            log.info(
                "Selenium-парсер отключен (ENABLE_PARSER=0). "
                "Поднимается только дашборд поверх существующей bets.db."
            )
        else:
            log.warning(
                "Selenium недоступен в этом окружении — работает только дашборд."
            )
    log.info("Дашборд: http://%s:%d", DASHBOARD_HOST, DASHBOARD_PORT)
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
